--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Ubuntu 17.2-1.pgdg22.04+1)
-- Dumped by pg_dump version 17.2 (Ubuntu 17.2-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE original;
--
-- Name: original; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE original WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE original OWNER TO postgres;

\connect original

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: timescaledb_toolkit; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb_toolkit WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb_toolkit; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb_toolkit IS 'Library of analytical hyperfunctions, time-series pipelining, and other SQL utilities';


--
-- Name: register_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.register_type AS ENUM (
    'float',
    'int',
    'bit'
);


ALTER TYPE public.register_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: registers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registers (
    ip_device character varying NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    register_adress integer NOT NULL,
    type public.register_type NOT NULL,
    value text
);


ALTER TABLE public.registers OWNER TO postgres;

--
-- Name: _hyper_6_11_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_11_chunk (
    CONSTRAINT constraint_11 CHECK ((("timestamp" >= '2024-12-13 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-01-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_11_chunk OWNER TO postgres;

--
-- Name: _hyper_6_12_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_12_chunk (
    CONSTRAINT constraint_12 CHECK ((("timestamp" >= '2025-02-11 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-03-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_12_chunk OWNER TO postgres;

--
-- Name: _hyper_6_13_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_13_chunk (
    CONSTRAINT constraint_13 CHECK ((("timestamp" >= '2025-03-13 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-04-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_13_chunk OWNER TO postgres;

--
-- Name: _hyper_6_14_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_14_chunk (
    CONSTRAINT constraint_14 CHECK ((("timestamp" >= '2025-04-12 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-05-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_14_chunk OWNER TO postgres;

--
-- Name: _hyper_6_15_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_15_chunk (
    CONSTRAINT constraint_15 CHECK ((("timestamp" >= '2025-06-11 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-07-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_15_chunk OWNER TO postgres;

--
-- Name: _hyper_6_16_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_16_chunk (
    CONSTRAINT constraint_16 CHECK ((("timestamp" >= '2025-07-11 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-08-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_16_chunk OWNER TO postgres;

--
-- Name: _hyper_6_17_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_17_chunk (
    CONSTRAINT constraint_17 CHECK ((("timestamp" >= '2025-09-09 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-10-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_17_chunk OWNER TO postgres;

--
-- Name: _hyper_6_18_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_18_chunk (
    CONSTRAINT constraint_18 CHECK ((("timestamp" >= '2025-10-09 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-11-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_18_chunk OWNER TO postgres;

--
-- Name: _hyper_6_19_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_19_chunk (
    CONSTRAINT constraint_19 CHECK ((("timestamp" >= '2025-11-08 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2025-12-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_19_chunk OWNER TO postgres;

--
-- Name: _hyper_6_20_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: postgres
--

CREATE TABLE _timescaledb_internal._hyper_6_20_chunk (
    CONSTRAINT constraint_20 CHECK ((("timestamp" >= '2026-01-07 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-02-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.registers);


ALTER TABLE _timescaledb_internal._hyper_6_20_chunk OWNER TO postgres;

--
-- Name: device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device (
    ip_adress character varying NOT NULL,
    port integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.device OWNER TO postgres;

--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
\.
COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM '$$PATH$$/5186.dat';

--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.
COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM '$$PATH$$/5192.dat';

--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.
COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM '$$PATH$$/5197.dat';

--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
\.
COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM '$$PATH$$/5188.dat';

--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.
COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM '$$PATH$$/5190.dat';

--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.
COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM '$$PATH$$/5194.dat';

--
-- Data for Name: chunk_index; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.chunk_index (chunk_id, index_name, hypertable_id, hypertable_index_name) FROM stdin;
\.
COPY _timescaledb_catalog.chunk_index (chunk_id, index_name, hypertable_id, hypertable_index_name) FROM '$$PATH$$/5196.dat';

--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.
COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM '$$PATH$$/5209.dat';

--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.compression_settings (relid, segmentby, orderby, orderby_desc, orderby_nullsfirst) FROM stdin;
\.
COPY _timescaledb_catalog.compression_settings (relid, segmentby, orderby, orderby_desc, orderby_nullsfirst) FROM '$$PATH$$/5208.dat';

--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, finalized) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, finalized) FROM '$$PATH$$/5202.dat';

--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM '$$PATH$$/5210.dat';

--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM '$$PATH$$/5211.dat';

--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM '$$PATH$$/5203.dat';

--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM '$$PATH$$/5206.dat';

--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM '$$PATH$$/5204.dat';

--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM '$$PATH$$/5207.dat';

--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.
COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM '$$PATH$$/5205.dat';

--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
\.
COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM '$$PATH$$/5201.dat';

--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: postgres
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.
COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM '$$PATH$$/5187.dat';

--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_config; Owner: postgres
--

COPY _timescaledb_config.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.
COPY _timescaledb_config.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM '$$PATH$$/5200.dat';

--
-- Data for Name: _hyper_6_11_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_11_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_11_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5524.dat';

--
-- Data for Name: _hyper_6_12_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_12_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_12_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5525.dat';

--
-- Data for Name: _hyper_6_13_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_13_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_13_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5526.dat';

--
-- Data for Name: _hyper_6_14_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_14_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_14_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5527.dat';

--
-- Data for Name: _hyper_6_15_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_15_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_15_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5528.dat';

--
-- Data for Name: _hyper_6_16_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_16_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_16_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5529.dat';

--
-- Data for Name: _hyper_6_17_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_17_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_17_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5530.dat';

--
-- Data for Name: _hyper_6_18_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_18_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_18_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5531.dat';

--
-- Data for Name: _hyper_6_19_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_19_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_19_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5532.dat';

--
-- Data for Name: _hyper_6_20_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: postgres
--

COPY _timescaledb_internal._hyper_6_20_chunk (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY _timescaledb_internal._hyper_6_20_chunk (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5533.dat';

--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device (ip_adress, port, name) FROM stdin;
\.
COPY public.device (ip_adress, port, name) FROM '$$PATH$$/5522.dat';

--
-- Data for Name: registers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registers (ip_device, "timestamp", register_adress, type, value) FROM stdin;
\.
COPY public.registers (ip_device, "timestamp", register_adress, type, value) FROM '$$PATH$$/5523.dat';

--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 40, true);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 20, true);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 6, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 20, true);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 6, true);


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_config; Owner: postgres
--

SELECT pg_catalog.setval('_timescaledb_config.bgw_job_id_seq', 1000, false);


--
-- Name: _hyper_6_11_chunk 11_22_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_11_chunk
    ADD CONSTRAINT "11_22_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_12_chunk 12_24_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_12_chunk
    ADD CONSTRAINT "12_24_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_13_chunk 13_26_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_13_chunk
    ADD CONSTRAINT "13_26_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_14_chunk 14_28_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_14_chunk
    ADD CONSTRAINT "14_28_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_15_chunk 15_30_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_15_chunk
    ADD CONSTRAINT "15_30_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_16_chunk 16_32_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_16_chunk
    ADD CONSTRAINT "16_32_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_17_chunk 17_34_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_17_chunk
    ADD CONSTRAINT "17_34_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_18_chunk 18_36_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_18_chunk
    ADD CONSTRAINT "18_36_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_19_chunk 19_38_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_19_chunk
    ADD CONSTRAINT "19_38_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: _hyper_6_20_chunk 20_40_registers_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_20_chunk
    ADD CONSTRAINT "20_40_registers_pkey" PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (ip_adress);


--
-- Name: registers registers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registers
    ADD CONSTRAINT registers_pkey PRIMARY KEY (ip_device, "timestamp", register_adress);


--
-- Name: registers ts_insert_blocker; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER ts_insert_blocker BEFORE INSERT ON public.registers FOR EACH ROW EXECUTE FUNCTION _timescaledb_functions.insert_blocker();


--
-- Name: _hyper_6_11_chunk 11_21_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_11_chunk
    ADD CONSTRAINT "11_21_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_12_chunk 12_23_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_12_chunk
    ADD CONSTRAINT "12_23_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_13_chunk 13_25_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_13_chunk
    ADD CONSTRAINT "13_25_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_14_chunk 14_27_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_14_chunk
    ADD CONSTRAINT "14_27_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_15_chunk 15_29_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_15_chunk
    ADD CONSTRAINT "15_29_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_16_chunk 16_31_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_16_chunk
    ADD CONSTRAINT "16_31_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_17_chunk 17_33_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_17_chunk
    ADD CONSTRAINT "17_33_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_18_chunk 18_35_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_18_chunk
    ADD CONSTRAINT "18_35_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_19_chunk 19_37_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_19_chunk
    ADD CONSTRAINT "19_37_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: _hyper_6_20_chunk 20_39_fk_ip_device; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: postgres
--

ALTER TABLE ONLY _timescaledb_internal._hyper_6_20_chunk
    ADD CONSTRAINT "20_39_fk_ip_device" FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- Name: registers fk_ip_device; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registers
    ADD CONSTRAINT fk_ip_device FOREIGN KEY (ip_device) REFERENCES public.device(ip_adress);


--
-- PostgreSQL database dump complete
--

